import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-ordersummary',
  templateUrl: './ordersummary.page.html',
  styleUrls: ['./ordersummary.page.scss'],
})
export class OrdersummaryPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
