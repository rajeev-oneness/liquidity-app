import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-mywallet',
  templateUrl: './mywallet.page.html',
  styleUrls: ['./mywallet.page.scss'],
})
export class MywalletPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
