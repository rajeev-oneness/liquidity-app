import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-vaultbalance',
  templateUrl: './vaultbalance.page.html',
  styleUrls: ['./vaultbalance.page.scss'],
})
export class VaultbalancePage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
