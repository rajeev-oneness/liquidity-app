import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-orderredeemed',
  templateUrl: './orderredeemed.page.html',
  styleUrls: ['./orderredeemed.page.scss'],
})
export class OrderredeemedPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
